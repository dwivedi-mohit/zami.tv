/**
 * CineSync Content Script
 * Injected into Disney+ Hotstar (*.hotstar.com) and MX Player (*.mxplayer.in)
 * Hooks the native HTML5 video player and synchronizes playback across 2-3 friends.
 */

(function () {
  console.log('[CineSync] Extension content script active on', window.location.hostname);

  let currentVideoEl = null;
  let socket = null;
  let currentRoomId = null;
  let currentUsername = 'Friend-' + Math.floor(100 + Math.random() * 900);
  let serverUrl = 'http://localhost:3000';
  let isRemoteAction = false;
  let widgetVisible = false;

  // 1. Locate the video player on the page (supports SPAs, Netflix, Prime, Hotstar, MX, Crunchyroll, YouTube)
  function findVideoElement() {
    const video = document.querySelector('video') ||
                  document.querySelector('.html5-main-video') ||
                  document.querySelector('#player0') ||
                  document.querySelector('.webPlayerSDKContainer video') ||
                  document.querySelector('.rendererContainer video');
    if (video && video !== currentVideoEl) {
      currentVideoEl = video;
      attachVideoListeners(video);
      console.log('[CineSync] Found and attached to video player on', window.location.hostname);
    }
  }

  // Observe DOM changes to catch dynamically inserted video players
  const observer = new MutationObserver(() => findVideoElement());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  findVideoElement();

  // Multi-platform safe playback controller (supports Netflix Cadmium API & HTML5)
  function safeSeek(time) {
    if (!currentVideoEl) return;
    try {
      const netflixPlayer = window.netflix?.appContext?.state?.playerApp?.getAPI()?.videoPlayer;
      if (netflixPlayer) {
        const sessionIds = netflixPlayer.getAllPlayerSessionIds();
        if (sessionIds && sessionIds.length > 0) {
          const player = netflixPlayer.getVideoPlayerBySessionId(sessionIds[sessionIds.length - 1]);
          if (player && typeof player.seek === 'function') {
            player.seek(time * 1000);
            return;
          }
        }
      }
    } catch (e) {}

    try {
      currentVideoEl.currentTime = time;
    } catch (e) {}
  }

  function safePlay() {
    if (!currentVideoEl) return;
    try {
      const netflixPlayer = window.netflix?.appContext?.state?.playerApp?.getAPI()?.videoPlayer;
      if (netflixPlayer) {
        const sessionIds = netflixPlayer.getAllPlayerSessionIds();
        if (sessionIds && sessionIds.length > 0) {
          const player = netflixPlayer.getVideoPlayerBySessionId(sessionIds[sessionIds.length - 1]);
          if (player && typeof player.play === 'function') {
            player.play();
            return;
          }
        }
      }
    } catch (e) {}
    currentVideoEl.play().catch(() => {});
  }

  function safePause() {
    if (!currentVideoEl) return;
    try {
      const netflixPlayer = window.netflix?.appContext?.state?.playerApp?.getAPI()?.videoPlayer;
      if (netflixPlayer) {
        const sessionIds = netflixPlayer.getAllPlayerSessionIds();
        if (sessionIds && sessionIds.length > 0) {
          const player = netflixPlayer.getVideoPlayerBySessionId(sessionIds[sessionIds.length - 1]);
          if (player && typeof player.pause === 'function') {
            player.pause();
            return;
          }
        }
      }
    } catch (e) {}
    try {
      currentVideoEl.pause();
    } catch (e) {}
  }

  // 2. Attach playback event listeners to the native video element
  function attachVideoListeners(video) {
    video.addEventListener('play', () => {
      if (isRemoteAction || !socket || !currentRoomId) return;
      socket.emit('media-play', { currentTime: video.currentTime });
    });

    video.addEventListener('pause', () => {
      if (isRemoteAction || !socket || !currentRoomId) return;
      socket.emit('media-pause', { currentTime: video.currentTime });
    });

    video.addEventListener('seeking', () => {
      if (isRemoteAction || !socket || !currentRoomId) return;
      socket.emit('media-seek', { currentTime: video.currentTime });
    });
  }

  // 3. Connect to CineSync WebSocket Server
  function connectToParty(roomId, user, hostUrl) {
    currentRoomId = roomId;
    currentUsername = user || currentUsername;
    serverUrl = hostUrl || serverUrl;

    if (socket) {
      socket.disconnect();
    }

    if (typeof io === 'undefined') {
      console.error('[CineSync] Socket.io client library not loaded');
      return;
    }

    socket = io(serverUrl, { transports: ['websocket', 'polling'] });

    socket.on('connect', () => {
      console.log('[CineSync] Connected to server at', serverUrl);
      socket.emit('join-room', {
        roomId: currentRoomId,
        username: currentUsername,
        avatarColor: '#6366f1'
      });
      updateStatusUI('Connected & Synced', '#10b981');
    });

    socket.on('room-joined', (data) => {
      appendChatMessage({
        type: 'system',
        text: `Connected to Party: "${currentRoomId}"`
      });
      // Synchronize video if room has active playback
      if (currentVideoEl && data.mediaSource && data.mediaSource.currentTime > 0) {
        applyRemoteSync(() => {
          safeSeek(data.mediaSource.currentTime);
          if (data.mediaSource.isPlaying) safePlay();
        });
      }
    });

    socket.on('media-play', ({ currentTime }) => {
      if (!currentVideoEl) return;
      applyRemoteSync(() => {
        const drift = Math.abs(currentVideoEl.currentTime - currentTime);
        if (drift > 1.0) safeSeek(currentTime);
        safePlay();
      });
    });

    socket.on('media-pause', ({ currentTime }) => {
      if (!currentVideoEl) return;
      applyRemoteSync(() => {
        safeSeek(currentTime);
        safePause();
      });
    });

    socket.on('media-seek', ({ currentTime }) => {
      if (!currentVideoEl) return;
      applyRemoteSync(() => {
        safeSeek(currentTime);
      });
    });

    socket.on('room-heartbeat', ({ currentTime, isPlaying }) => {
      if (!currentVideoEl) return;
      const drift = Math.abs(currentVideoEl.currentTime - currentTime);
      if (drift > 1.5) {
        applyRemoteSync(() => {
          safeSeek(currentTime);
          if (isPlaying && currentVideoEl.paused) safePlay();
          else if (!isPlaying && !currentVideoEl.paused) safePause();
        });
      }
    });

    socket.on('chat-message', (msg) => {
      appendChatMessage(msg);
    });

    socket.on('new-reaction', ({ emoji }) => {
      spawnFloatingReaction(emoji);
    });

    socket.on('disconnect', () => {
      updateStatusUI('Disconnected', '#ef4444');
    });
  }

  function applyRemoteSync(fn) {
    isRemoteAction = true;
    try {
      fn();
    } finally {
      setTimeout(() => { isRemoteAction = false; }, 250);
    }
  }

  // 4. Injected UI Widget
  function createWidget() {
    if (document.getElementById('cinesync-root')) return;

    const root = document.createElement('div');
    root.id = 'cinesync-root';

    root.innerHTML = `
      <div id="cinesync-pill-btn" class="cinesync-trigger-btn" title="Open CineSync Watch Party">
        <span>🎬</span>
        <span>CineSync</span>
      </div>

      <div id="cinesync-card" class="cinesync-party-card" style="display: none;">
        <div class="cinesync-header">
          <div class="cinesync-room-pill">
            <div id="cinesync-status-dot" class="cinesync-status-dot"></div>
            <span id="cinesync-room-title">Party Offline</span>
          </div>
          <div class="cinesync-actions-row">
            <button id="cinesync-btn-resync" class="cinesync-icon-btn" title="Force Re-Sync">↻</button>
            <button id="cinesync-btn-close" class="cinesync-icon-btn" title="Minimize">✕</button>
          </div>
        </div>

        <div class="cinesync-reactions-bar">
          <button class="cinesync-react-btn" data-emoji="🍿">🍿</button>
          <button class="cinesync-react-btn" data-emoji="❤️">❤️</button>
          <button class="cinesync-react-btn" data-emoji="😂">😂</button>
          <button class="cinesync-react-btn" data-emoji="🔥">🔥</button>
          <button class="cinesync-react-btn" data-emoji="👏">👏</button>
        </div>

        <div id="cinesync-chat-body" class="cinesync-chat-body">
          <div class="cinesync-chat-sys">Welcome to CineSync Watch Party!</div>
        </div>

        <form id="cinesync-chat-form" class="cinesync-chat-input-bar">
          <input type="text" id="cinesync-chat-input" class="cinesync-chat-input" placeholder="Chat with room..." autocomplete="off">
          <button type="submit" class="cinesync-chat-send">Send</button>
        </form>
      </div>
    `;

    document.body.appendChild(root);

    // Event handlers
    const pillBtn = document.getElementById('cinesync-pill-btn');
    const card = document.getElementById('cinesync-card');
    const closeBtn = document.getElementById('cinesync-btn-close');
    const resyncBtn = document.getElementById('cinesync-btn-resync');
    const chatForm = document.getElementById('cinesync-chat-form');
    const chatInput = document.getElementById('cinesync-chat-input');

    pillBtn.addEventListener('click', () => {
      widgetVisible = !widgetVisible;
      card.style.display = widgetVisible ? 'flex' : 'none';
      pillBtn.style.display = widgetVisible ? 'none' : 'flex';
      if (!socket) {
        promptJoinRoom();
      }
    });

    closeBtn.addEventListener('click', () => {
      widgetVisible = false;
      card.style.display = 'none';
      pillBtn.style.display = 'flex';
    });

    if (resyncBtn) {
      resyncBtn.addEventListener('click', () => {
        if (socket) socket.emit('request-sync');
      });
    }

    if (chatForm && chatInput) {
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = chatInput.value.trim();
        if (!text || !socket) return;
        socket.emit('send-chat', { text });
        chatInput.value = '';
      });
    }

    // Reaction clicks
    const reactBtns = root.querySelectorAll('.cinesync-react-btn');
    reactBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const emoji = btn.dataset.emoji;
        if (socket) socket.emit('send-reaction', { emoji });
        spawnFloatingReaction(emoji);
      });
    });
  }

  function promptJoinRoom() {
    chrome.storage.local.get(['cinesync_room', 'cinesync_username', 'cinesync_server'], (res) => {
      const defaultRoom = res.cinesync_room || 'party-movie-42';
      const defaultUser = res.cinesync_username || currentUsername;
      const defaultServer = res.cinesync_server || serverUrl;

      const roomInput = prompt('Enter CineSync Room Code to join:', defaultRoom);
      if (!roomInput) return;

      chrome.storage.local.set({ cinesync_room: roomInput });
      connectToParty(roomInput, defaultUser, defaultServer);
    });
  }

  function updateStatusUI(text, color) {
    const dot = document.getElementById('cinesync-status-dot');
    const title = document.getElementById('cinesync-room-title');
    if (dot) dot.style.backgroundColor = color;
    if (title) title.textContent = `${currentRoomId || 'Party'} (${text})`;
  }

  function appendChatMessage(msg) {
    const body = document.getElementById('cinesync-chat-body');
    if (!body) return;

    const el = document.createElement('div');
    if (msg.type === 'system') {
      el.className = 'cinesync-chat-sys';
      el.textContent = msg.text;
    } else {
      el.className = 'cinesync-chat-msg';
      el.innerHTML = `
        <span class="cinesync-chat-author" style="color: ${msg.color || '#a5b4fc'}">${escape(msg.sender)}:</span>
        <span class="cinesync-chat-text">${escape(msg.text)}</span>
      `;
    }
    body.appendChild(el);
    body.scrollTop = body.scrollHeight;
  }

  function spawnFloatingReaction(emoji) {
    const el = document.createElement('div');
    el.className = 'cinesync-floating-particle';
    el.textContent = emoji;
    el.style.left = (window.innerWidth / 2 + (Math.random() - 0.5) * 200) + 'px';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2500);
  }

  function escape(str) {
    const p = document.createElement('p');
    p.textContent = str || '';
    return p.innerHTML;
  }

  // Listen for messages from extension popup
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === 'CONNECT_ROOM') {
      connectToParty(req.roomId, req.username, req.serverUrl);
      createWidget();
      const card = document.getElementById('cinesync-card');
      const pill = document.getElementById('cinesync-pill-btn');
      if (card) card.style.display = 'flex';
      if (pill) pill.style.display = 'none';
      sendResponse({ success: true });
    }
    return true;
  });

  // Auto-create trigger widget once page is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createWidget);
  } else {
    createWidget();
  }
})();
